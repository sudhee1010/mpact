import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import SplitType from "split-type";

gsap.registerPlugin(ScrollTrigger);

const FEATURES = [
  { text: "SHELF STABLE", bg: "bg-yellow-400", color: "text-black", side: "left" },
  { text: "PROTEIN + CAFFEINE", bg: "bg-orange-500", color: "text-white", side: "right" },
  { text: "INFINITELY RECYCLABLE", bg: "bg-red-600", color: "text-white", side: "left" },
  { text: "LACTOSE FREE", bg: "bg-yellow-400", color: "text-black", side: "right" },
];

export default function FeaturesSection() {
  const sectionRef = useRef(null);
  const headlineRef = useRef(null);
  const bgRef = useRef(null);
  const itemsRef = useRef([]);
  const footerRef = useRef(null);
  const splitRef = useRef(null);

  useEffect(() => {
    const ctx = gsap.context(() => {

      /* ================= PINNED MASTER TIMELINE ================= */
      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "+=200%",
          scrub: true,
          pin: true,
        },
      });

      /* ================= BACKGROUND PARALLAX ================= */
      tl.fromTo(
        bgRef.current,
        { y: 80 },
        { y: -80, ease: "none" },
        0
      );

      /* ================= HEADLINE SPLIT ================= */
      splitRef.current = new SplitType(headlineRef.current, { types: "chars" });

      tl.fromTo(
        splitRef.current.chars,
        { yPercent: 120, opacity: 0 },
        {
          yPercent: 0,
          opacity: 1,
          stagger: 0.04,
          ease: "power3.out",
        },
        0.1
      );

      /* ================= FEATURE BOXES ================= */
      itemsRef.current.forEach((el, i) => {
        const fromX = FEATURES[i].side === "left" ? -80 : 80;

        tl.fromTo(
          el,
          { x: fromX, opacity: 0, scale: 0.95 },
          {
            x: 0,
            opacity: 1,
            scale: 1,
            ease: "power3.out",
          },
          0.3 + i * 0.1
        );

        // REAL parallax drift
        tl.to(
          el,
          {
            y: i % 2 === 0 ? -20 : 20,
            ease: "none",
          },
          0
        );
      });

      /* ================= FOOTER ================= */
      tl.fromTo(
        footerRef.current,
        { y: 40, opacity: 0 },
        { y: 0, opacity: 1, ease: "power2.out" },
        0.9
      );

    }, sectionRef);

    return () => {
      splitRef.current?.revert();
      ctx.revert();
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-neutral-900 overflow-hidden"
    >
      {/* PARALLAX BACKGROUND */}
      {/* <div
        ref={bgRef}
        className="absolute inset-0 bg-gradient-to-b
                   from-neutral-800/60 via-neutral-900 to-neutral-900"
      /> */}

      <div className="relative z-10 container mx-auto px-4 h-screen flex flex-col justify-center">
        {/* HEADLINE */}
        <h2
          ref={headlineRef}
          className="text-center text-5xl md:text-6xl
                     font-black text-yellow-400 mb-16"
        >
          BUILT FOR MODERN ENERGY
        </h2>

        {/* FEATURES */}
        <div className="max-w-2xl mx-auto space-y-6">
          {FEATURES.map((f, i) => (
            <div
              key={i}
              ref={el => (itemsRef.current[i] = el)}
              className={`${f.bg} ${f.color}
                          text-3xl font-black text-center
                          py-4 px-8 rounded-md
                          will-change-transform`}
            >
              {f.text}
            </div>
          ))}
        </div>

        {/* FOOTER */}
        <div
          ref={footerRef}
          className="mt-16 text-center text-gray-400 text-lg"
        >
          And much more…
        </div>
      </div>
    </section>
  );
}
