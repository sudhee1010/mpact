import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import SplitType from "split-type";

gsap.registerPlugin(ScrollTrigger);

export default function MotivationalSection() {
  const sectionRef = useRef(null);
  const fuelRef = useRef(null);
  const splitsRef = useRef([]);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const lines = gsap.utils.toArray(".scrub-line", sectionRef.current);
      const allWords = [];

      lines.forEach(line => {
        const split = new SplitType(line, {
          types: "words",
          wordClass: "split-word",
        });
        splitsRef.current.push(split);
        allWords.push(...split.words);
      });

      gsap.set(allWords, {
        display: "inline-block",
        opacity: 0.15,
        color: "#9ca3af", // gray-400
        transformOrigin: "bottom",
      });

      gsap.to(allWords, {
        opacity: 1,
        color: "rgba(250, 204, 21, 0.95)",
        stagger: 0.8,
        ease: "power1.out",
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top 60%",
          end: "bottom center", // ✅ FIX
          scrub: true,
          invalidateOnRefresh: true,
        },
      });

      gsap.fromTo(
        fuelRef.current,
        { scaleX: 0, opacity: 0 },
        {
          scaleX: 1,
          opacity: 1,
          duration: 1,
          ease: "power4.out",
          transformOrigin: "left center",
          scrollTrigger: {
            trigger: fuelRef.current,
            start: "top 60%",
          },
        }
      );
    }, sectionRef);

    return () => {
      splitsRef.current.forEach(split => split.revert());
      ctx.revert();
    };
  }, []);

  return (
   <section
  ref={sectionRef}
  className="w-full flex items-center justify-center bg-black px-4 py-24"
>
  <div className="text-center max-w-6xl w-full">
    <h2 className="font-black leading-[1.1] tracking-tight text-white">
      
      <div className="scrub-line text-[3rem] sm:text-[5rem] md:text-[7rem]">
        STIR UP YOUR
      </div>

      <div className="scrub-line text-[3rem] sm:text-[5rem] md:text-[7rem]">
        FEARLESS PAST AND
      </div>

      <div className="my-6 flex justify-center">
        <span
          ref={fuelRef}
          className="inline-block bg-[#FFED23] text-[#333333] rounded-xl px-8 py-3 text-[2.5rem] sm:text-[4rem] md:text-[5rem] font-black whitespace-nowrap"
          style={{ transform: "scaleX(0)" }}
        >
          FUEL UP
        </span>
      </div>

      <div className="scrub-line text-[3rem] sm:text-[5rem] md:text-[7rem]">
        YOUR FUTURE WITH EVERY
      </div>

      <div className="scrub-line text-[3rem] sm:text-[5rem] md:text-[7rem]">
        GULP OF PERFECTION PROTEIN
      </div>

    </h2>
  </div>
</section>

  );
}
