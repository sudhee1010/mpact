import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import SplitType from "split-type";

gsap.registerPlugin(ScrollTrigger);

/* ================= VIDEO CONFIG ================= */

const videos = [
  { id: 1, src: "/videos/v1.mp4", x: -260, y: -40, rotate: -8, scale: 0.95 },
  { id: 2, src: "/videos/v2.mp4", x: -130, y: -80, rotate: -4, scale: 1 },
  { id: 3, src: "/videos/v3.mp4", x: 0,    y: -20, rotate: 0,  scale: 1.05 },
  { id: 4, src: "/videos/v4.mp4", x: 130,  y: 60,  rotate: 4,  scale: 1 },
  { id: 5, src: "/videos/v5.mp4", x: 260,  y: 20,  rotate: 8,  scale: 0.95 },
];

export default function VideoShowcaseSection() {
  const sectionRef = useRef(null);
  const circleRef = useRef(null);
  const cardsRef = useRef([]);
  const textRef = useRef(null);

  const isDesktop =
    typeof window !== "undefined" &&
    window.matchMedia("(hover: hover)").matches;

  useEffect(() => {
    const ctx = gsap.context(() => {
      /* ================= PIN MASTER ================= */

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "+=250%",
          scrub: true,
          pin: true,
        },
      });

      /* ================= BACKGROUND TEXT ================= */

      const split = new SplitType(textRef.current, { types: "words" });

      tl.fromTo(
        split.words,
        { x: -80, opacity: 0 },
        {
          x: 0,
          opacity: 0.12,
          stagger: 0.12,
          ease: "power2.out",
        },
        0
      );

      /* ================= INITIAL CARD SET ================= */

      cardsRef.current.forEach((card, i) => {
        gsap.set(card, {
          x: videos[i].x,
          y: videos[i].y,
          rotation: videos[i].rotate,
          scale: videos[i].scale,
        });
      });

      /* ================= CARD REVEAL ================= */

      tl.fromTo(
        cardsRef.current,
        { opacity: 0, y: 60, scale: 0.95 },
        {
          opacity: 1,
          y: 0,
          stagger: 0.12,
          ease: "power3.out",
        },
        0.15
      );

      /* ================= PARALLAX DRIFT ================= */

      cardsRef.current.forEach((card, i) => {
        tl.to(
          card,
          {
            x: videos[i].x * 1.25,
            y: videos[i].y * 1.25,
            ease: "none",
          },
          0
        );
      });

      /* ================= EXPANDING CIRCLE ================= */

      tl.fromTo(
        circleRef.current,
        {
          width: "12vw",
          height: "12vw",
          borderRadius: "50%",
        },
        {
          width: "150vw",
          height: "150vw",
          borderRadius: "75vw",
          ease: "power2.inOut",
        },
        0.35
      );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  /* ================= HOVER VIDEO ================= */

  const onEnter = video => {
    if (!isDesktop) return;
    video.play();
  };

  const onLeave = video => {
    if (!isDesktop) return;
    video.pause();
    video.currentTime = 0;
  };

  return (
    <section
      ref={sectionRef}
      className="relative h-screen bg-black overflow-hidden"
    >
      {/* ================= BACKGROUND TEXT ================= */}
      <h2
        ref={textRef}
        className="absolute inset-0 flex items-center justify-center
                   text-[12vw] font-black text-yellow-400/95
                   pointer-events-none z-20"
      >
        WHAT’S EVERYONE TALKING
      </h2>

      {/* ================= EXPANDING CIRCLE ================= */}
      <div
        ref={circleRef}
        className="absolute left-1/2 top-1/2
                   -translate-x-1/2 -translate-y-1/2
                   bg-yellow-400/95
                   z-10 pointer-events-none"
      />

      {/* ================= VIDEO CARDS ================= */}
      <div className="relative z-30 h-full w-full">
        {videos.map((v, i) => (
          <div
            key={v.id}
            ref={el => (cardsRef.current[i] = el)}
            className="
              absolute left-1/2 top-1/2
              w-56 aspect-[9/16]
              rounded-2xl overflow-hidden
              bg-transparent
              shadow-[0_40px_80px_rgba(0,0,0,0.45)]
              transition-transform duration-300
              hover:scale-[1.05]
            "
            style={{ transform: "translate(-50%, -50%)" }}
          >
            <video
              src={v.src}
              muted
              playsInline
              preload="none"
              className="w-full h-full object-cover"
              onMouseEnter={e => onEnter(e.currentTarget)}
              onMouseLeave={e => onLeave(e.currentTarget)}
            />
          </div>
        ))}
      </div>
    </section>
  );
}
