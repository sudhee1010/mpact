import React, { useState, useEffect, useRef } from 'react';
import { ShoppingCart, User, Search, ChevronLeft, ChevronRight, Play, Menu, X } from 'lucide-react';
import MotivationalSection from "./MotivationalSection";
import VideoShowcaseSection from "./VideoShowcaseSection";
import FeaturesSection from "./FeaturesSection";




const MPACTLandingPage = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [scrollY, setScrollY] = useState(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const heroRef = useRef(null);
  const motivationalRef = useRef(null);
  const productsRef = useRef(null);
  const aboutRef = useRef(null);
  const blogRef = useRef(null);
  
  // Load Jersey 25 font
  useEffect(() => {
    const link = document.createElement('link');
    link.href = 'https://fonts.googleapis.com/css2?family=Jersey+25&display=swap';
    link.rel = 'stylesheet';
    document.head.appendChild(link);
    
    return () => {
      document.head.removeChild(link);
    };
  }, []);
  
  useEffect(() => {
    const handleScroll = () => {
      setScrollY(window.scrollY);
    };
    
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-switching carousel
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide(prev => (prev === heroSlides.length - 1 ? 0 : prev + 1));
    }, 5000); // Switch every 5 seconds
    
    return () => clearInterval(interval);
  }, []);

  const heroSlides = [
    {
      id: 1,
      image: "./src/assets/rrs/protein-gym.jpg"
    },
    {
      id: 2,
      image: "./src/assets/rrs/protein-gym.jpg"
    },
    {
      id: 3,
      image: "./src/assets/rrs/protein-gym.jpg"
    }
  ];

  // Smooth scroll to section
  const scrollToSection = (ref) => {
    ref.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };
  
  // This is where you'll fetch from your backend
  const [products, setProducts] = useState([
    {
      id: 1,
      title: "EXTRA HUNGRY?",
      name: "PROTEIN WAFERS - VARIETY PACK OF 10",
      brand: "SNICKERS",
      price: 2000,
      oldPrice: 2999,
      discount: "26% OFF",
      image: "./src/assets/rrs/protein-gym.jpg",
      rating: 5,
      reviews: 199,
      specs: ["NO PRESERVATIVES", "JAGGERY BASED", "NO ADDED COLOURS", "NO GLUCOSE ADDED", "80 % PEANUT", "NO ADDED COLOURS"]
    },
    {
      id: 2,
      title: "EXTRA HUNGRY?",
      name: "PROTEIN WAFERS - VARIETY PACK OF 10",
      brand: "SNICKERS",
      price: 2000,
      oldPrice: 2999,
      discount: "26% OFF",
      image: "./src/assets/rrs/protein-gym.jpg",
      rating: 5,
      reviews: 199,
      specs: ["NO PRESERVATIVES", "JAGGERY BASED", "NO ADDED COLOURS", "NO GLUCOSE ADDED", "80 % PEANUT", "NO ADDED COLOURS"]
    },
    {
      id: 3,
      title: "EXTRA HUNGRY?",
      name: "PROTEIN WAFERS - VARIETY PACK OF 10",
      brand: "SNICKERS",
      price: 2000,
      oldPrice: 2999,
      discount: "26% OFF",
      image: "./src/assets/rrs/protein-gym.jpg",
      rating: 5,
      reviews: 199,
      specs: ["NO PRESERVATIVES", "JAGGERY BASED", "NO ADDED COLOURS", "NO GLUCOSE ADDED", "80 % PEANUT", "NO ADDED COLOURS"]
    },
    {
      id: 4,
      title: "EXTRA HUNGRY?",
      name: "PROTEIN WAFERS - VARIETY PACK OF 10",
      brand: "SNICKERS",
      price: 2000,
      oldPrice: 2999,
      discount: "26% OFF",
      image: "./src/assets/rrs/protein-gym.jpg",
      rating: 5,
      reviews: 199,
      specs: ["NO PRESERVATIVES", "JAGGERY BASED", "NO ADDED COLOURS", "NO GLUCOSE ADDED", "80 % PEANUT", "NO ADDED COLOURS"]
    }
  ]);

  // Backend Integration Example:
  // useEffect(() => {
  //   const fetchProducts = async () => {
  //     try {
  //       const response = await fetch('/api/products');
  //       const data = await response.json();
  //       setProducts(data);
  //     } catch (error) {
  //       console.error('Error fetching products:', error);
  //     }
  //   };
  //   fetchProducts();
  // }, []);

  const handlePrevSlide = () => {
    setCurrentSlide(prev => (prev === 0 ? heroSlides.length - 1 : prev - 1));
  };

  const handleNextSlide = () => {
    setCurrentSlide(prev => (prev === heroSlides.length - 1 ? 0 : prev + 1));
  };

  const handleBuyNow = async (productId) => {
    console.log('Buy now:', productId);
  };

  // Calculate parallax transforms
  const heroParallax = scrollY * 0.5;
  const productParallax = Math.max(0, (scrollY - 600) * 0.3);
  const motivationalParallax = Math.max(0, (scrollY - 1200) * 0.4);

  return (
    <div className="min-h-screen bg-neutral-900 text-white overflow-x-hidden" style={{ fontFamily: "'Jersey 25', sans-serif" }}>
      {/* Fixed Header with fade effect */}
      <header 
        className="fixed top-0 left-0 right-0 z-50 bg-yellow-400 text-black transition-all duration-300"
        style={{
          backgroundColor: scrollY > 100 ? 'rgba(250, 204, 21, 0.95)' : 'rgb(250, 204, 21)',
          backdropFilter: scrollY > 100 ? 'blur(10px)' : 'none'
        }}
      >
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-3xl font-bold cursor-pointer" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}>
            MPACT
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex gap-8 text-sm font-bold">
            <button onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} className="hover:underline">HOME</button>
            <button onClick={() => scrollToSection(productsRef)} className="hover:underline">PRODUCTS</button>
            <button onClick={() => scrollToSection(aboutRef)} className="hover:underline">ABOUT US</button>
            <button onClick={() => scrollToSection(blogRef)} className="hover:underline">BLOG</button>
          </nav>
          
          <div className="flex items-center gap-4">
            <button className="hover:opacity-70 transition-opacity">
              <Search size={20} />
            </button>
            <button className="hover:opacity-70 transition-opacity">
              <User size={20} />
            </button>
            <button className="hover:opacity-70 transition-opacity">
              <ShoppingCart size={20} />
            </button>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden hover:opacity-70 transition-opacity"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
        
        {/* Mobile Navigation Menu */}
        <div 
          className={`md:hidden overflow-hidden transition-all duration-300 ${
            mobileMenuOpen ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
          }`}
        >
          <nav className="flex flex-col border-t border-black/10">
            <button 
              onClick={() => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
                setMobileMenuOpen(false);
              }} 
              className="px-4 py-3 text-left font-bold hover:bg-black/5 transition-colors border-b border-black/5"
            >
              HOME
            </button>
            <button 
              onClick={() => {
                scrollToSection(productsRef);
                setMobileMenuOpen(false);
              }} 
              className="px-4 py-3 text-left font-bold hover:bg-black/5 transition-colors border-b border-black/5"
            >
              PRODUCTS
            </button>
            <button 
              onClick={() => {
                scrollToSection(aboutRef);
                setMobileMenuOpen(false);
              }} 
              className="px-4 py-3 text-left font-bold hover:bg-black/5 transition-colors border-b border-black/5"
            >
              ABOUT US
            </button>
            <button 
              onClick={() => {
                scrollToSection(blogRef);
                setMobileMenuOpen(false);
              }} 
              className="px-4 py-3 text-left font-bold hover:bg-black/5 transition-colors"
            >
              BLOG
            </button>
          </nav>
        </div>
      </header>

      {/* Hero Slider with Parallax */}
      <section ref={heroRef} className="relative bg-black pt-20 overflow-hidden">
        <div className="container mx-auto px-4 py-12">
          <div className="relative">
            {/* Carousel Content */}
            <div className="relative min-h-[500px] md:min-h-[600px] flex items-center justify-center">
              {heroSlides.map((slide, index) => (
                <div
                  key={slide.id}
                  className={`absolute inset-0 transition-all duration-700 ${
                    index === currentSlide 
                      ? 'opacity-100 scale-100' 
                      : 'opacity-0 scale-95 pointer-events-none'
                  }`}
                >
                  <div 
                    className="w-full h-full flex items-center justify-center"
                    style={{
                      transform: index === currentSlide ? `translateY(${scrollY * 0.3}px)` : 'translateY(0)',
                      transition: 'transform 0.1s linear'
                    }}
                  >
                    <img 
                      src={slide.image} 
                      alt={`Slide ${index + 1}`} 
                      className="w-full h-full object-contain max-w-5xl mx-auto"
                    />
                  </div>
                </div>
              ))}
            </div>
            
            {/* Carousel Controls - Centered at Bottom */}
            <div className="flex items-center justify-center gap-4 mt-8">
              <button 
                onClick={handlePrevSlide}
                className="w-12 h-12 flex items-center justify-center bg-white/10 hover:bg-white/20 rounded-full transition-all hover:scale-110"
              >
                <ChevronLeft />
              </button>
              
              {/* Slide Indicators */}
              <div className="flex gap-2">
                {heroSlides.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-3 h-3 rounded-full transition-all duration-300 ${
                      index === currentSlide 
                        ? 'bg-yellow-400 w-8' 
                        : 'bg-white/30 hover:bg-white/50'
                    }`}
                  />
                ))}
              </div>
              
              <button 
                onClick={handleNextSlide}
                className="w-12 h-12 flex items-center justify-center bg-white/10 hover:bg-white/20 rounded-full transition-all hover:scale-110"
              >
                <ChevronRight />
              </button>
            </div>
          </div>
          
          <div className="flex justify-end mt-8">
            <img src="/api/placeholder/150/60" alt="Mars logo" className="h-16 transition-transform hover:scale-110" />
          </div>
        </div>
      </section>

      {/* Products Grid with Parallax */}
      <section ref={productsRef} id="products" className="py-16 bg-neutral-800 relative overflow-hidden">
        <div 
          className="absolute inset-0 opacity-10"
          style={{ 
            backgroundImage: 'radial-gradient(circle at 50% 50%, #fbbf24 1px, transparent 1px)',
            backgroundSize: '50px 50px',
            transform: `translateY(${productParallax}px)`
          }}
        />
        
        <div className="container mx-auto px-4 relative z-10">
          <h2 
            className="text-5xl md:text-6xl font-black text-yellow-400 text-center mb-12 transition-all duration-700"
            style={{
              transform: scrollY > 400 ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.9)',
              opacity: scrollY > 400 ? 1 : 0
            }}
          >
            FIND OUR PRODUCTS
          </h2>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            {products.map((product, index) => (
              <div 
                key={product.id} 
                className="bg-gradient-to-b from-yellow-900/40 to-neutral-800 border-2 border-yellow-800/50 rounded-lg overflow-hidden transform transition-all duration-500 hover:scale-105 hover:shadow-2xl hover:border-yellow-600"
                style={{
                  transform: scrollY > 500 + (index * 50) ? 'translateY(0)' : 'translateY(100px)',
                  opacity: scrollY > 500 + (index * 50) ? 1 : 0,
                  transitionDelay: `${index * 100}ms`
                }}
              >
                {/* Product Image Section with Title */}
                <div className="relative aspect-[3/4] bg-gradient-to-b from-amber-800 via-amber-700 to-amber-900 overflow-hidden group">
                  {/* Dynamic Title at top from backend */}
                  <div className="absolute top-2 left-0 right-0 z-10 text-center">
                    {product.title && (
                      <>
                        <h3 className="text-xl md:text-2xl font-black text-white mb-1" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>
                          {product.title.split(' ')[0]}
                        </h3>
                        <h3 className="text-xl md:text-2xl font-black text-white" style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.5)' }}>
                          {product.title.split(' ').slice(1).join(' ')}
                        </h3>
                      </>
                    )}
                    {product.brand && (
                      <div className="mt-1">
                        <span className="bg-blue-700 text-white px-2 py-0.5 text-xs font-black italic inline-block transform -skew-x-12">
                          {product.brand}
                        </span>
                      </div>
                    )}
                  </div>
                  
                  {/* Product Image */}
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  
                  {/* Gradient at bottom */}
                  <div className="absolute bottom-0 left-0 right-0 h-16 bg-gradient-to-t from-amber-900 to-transparent" />
                </div>
                
                {/* Product Details Section */}
                <div className="p-3 bg-neutral-900">
                  <h3 className="text-xs font-bold mb-2 uppercase text-white">{product.name}</h3>
                  
                  {/* Specs/Tags Grid - Dynamic from backend */}
                  <div className="grid grid-cols-2 gap-1.5 mb-2">
                    {product.specs.map((spec, i) => (
                      <div key={i} className="border border-yellow-600/50 rounded px-1.5 py-0.5 text-[9px] font-bold text-center text-yellow-400">
                        {spec}
                      </div>
                    ))}
                  </div>
                  
                  {/* Rating - Dynamic from backend */}
                  <div className="flex items-center gap-1 mb-2">
                    <div className="flex">
                      {"★".repeat(product.rating).split('').map((star, i) => (
                        <span key={i} className="text-yellow-400 text-xs">{star}</span>
                      ))}
                      {"☆".repeat(5 - product.rating).split('').map((star, i) => (
                        <span key={i} className="text-gray-600 text-xs">{star}</span>
                      ))}
                    </div>
                    <span className="text-[10px] text-gray-400">⭐ {product.reviews} Reviews</span>
                  </div>
                  
                  {/* Price - Dynamic from backend */}
                  <div className="mb-1">
                    <span className="text-[10px] text-gray-500 line-through">₹{product.oldPrice}</span>
                    <span className="text-[10px] text-green-400 ml-1">{product.discount}</span>
                  </div>
                  
                  <div className="text-lg font-black mb-3 text-white">RS : {product.price}</div>
                  
                  {/* Place Order Button */}
                  <button 
                    onClick={() => handleBuyNow(product.id)}
                    className="w-full bg-yellow-400 text-black font-black py-2 rounded hover:bg-yellow-500 transition-all transform hover:scale-105 active:scale-95 text-xs"
                  >
                    PLACE ORDER
                  </button>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <button className="bg-yellow-400 text-black font-bold px-8 py-3 rounded hover:bg-yellow-500 transition-all transform hover:scale-105 active:scale-95">
              SEE MORE →
            </button>
          </div>
        </div>
      </section>

      {/* Motivational Section with Parallax */}
      <MotivationalSection />
      {/* About Us Section with Parallax */}
      {/* <section ref={aboutRef} className="py-20 bg-black">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl md:text-6xl font-black text-yellow-400 mb-8">ABOUT US</h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto">
            At MPACT, we're revolutionizing the way you fuel your day. Our protein-packed products 
            are designed for those who refuse to compromise on taste or nutrition.
          </p>
        </div>
      </section> */}
     
        {/* Features Section */}
      <FeaturesSection />


     <VideoShowcaseSection />

    
     
      {/* Store Locator with Parallax */}
      <section className="py-16 bg-yellow-400 overflow-hidden">
        <div className="container mx-auto px-4 text-center">
          <h2 
            className="text-5xl md:text-6xl font-black text-black mb-8 transition-all duration-700"
            style={{
              transform: scrollY > 2600 ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.9)',
              opacity: scrollY > 2600 ? 1 : 0
            }}
          >
            FIND OUR NEAREST STORE
          </h2>
          <div 
            className="max-w-3xl mx-auto transition-all duration-700"
            style={{
              transform: scrollY > 2700 ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.95)',
              opacity: scrollY > 2700 ? 1 : 0
            }}
          >
            <img 
              src="/api/placeholder/800/300" 
              alt="Store locator map" 
              className="w-full rounded-lg shadow-2xl hover:shadow-yellow-600/50 transition-shadow duration-300"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section ref={blogRef} className="py-20 bg-black overflow-hidden">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-5xl md:text-6xl font-black text-yellow-400 mb-8">BLOG</h2>
          <p className="text-gray-300 text-lg max-w-3xl mx-auto mb-12">
            Stay updated with the latest news, recipes, and fitness tips from the MPACT community.
          </p>
          
          <h2 
            className="text-6xl md:text-8xl font-black text-yellow-400 mb-8 transition-all duration-700 hover:scale-110 cursor-default"
            style={{
              transform: scrollY > 3000 ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.8)',
              opacity: scrollY > 3000 ? 1 : 0
            }}
          >
            #GET IT NOW
          </h2>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-900 border-t border-neutral-800 py-8">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-2xl font-bold">MPACT</div>
            <div className="flex gap-6 text-sm">
              <a href="#" className="hover:text-yellow-400 transition-colors">PRIVACY POLICY</a>
              <a href="#" className="hover:text-yellow-400 transition-colors">TERMS OF USE</a>
            </div>
            <div className="flex gap-4">
              <a href="#" className="hover:text-yellow-400 transition-all hover:scale-110">FB</a>
              <a href="#" className="hover:text-yellow-400 transition-all hover:scale-110">TW</a>
              <a href="#" className="hover:text-yellow-400 transition-all hover:scale-110">IG</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default MPACTLandingPage;