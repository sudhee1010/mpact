import { useState } from "react";
import { Routes, Route } from "react-router-dom";

import Loader from "./components/Loader";
import Navbar from "./components/Navbar";

import Home from "./pages/Home/Home";
import Product from "./pages/Product";
import ProductPage from "./pages/ProductSpec";
import Checkout from "./pages/Checkout";
import Cart from "./pages/Cart";
import Payment from "./pages/Payment";
import OrderSuccess from "./pages/Ordersuccess";
import Trackpage from "./pages/Trackpage";
import Review from "./pages/review";

import About from "./pages/About/About";
import Faq from "./pages/faq/Faq";

import Profile from "./pages/profile/Profile";
import Prfle from "./pages/profile/Prfle";
import Input from "./pages/input/Input";

import "./index.css";

function App() {
  const [loading, setLoading] = useState(true);

  return (
    <>
      {/* FIXED NAVBAR */}
      <Navbar />

      {/* LOADER – ABOVE EVERYTHING */}
      {loading && <Loader onFinish={() => setLoading(false)} />}

      {/* PAGE CONTENT (offset for fixed navbar) */}
      <div className="page-wrapper pt-[96px]">
        <Routes>
          <Route path="/" element={<Home />} />

          {/* PRODUCTS */}
          <Route path="/products" element={<Product />} />
          <Route path="/productspec" element={<ProductPage />} />

          {/* CART & ORDER FLOW */}
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="/success" element={<OrderSuccess />} />
          <Route path="/trackorder" element={<Trackpage />} />
          <Route path="/review" element={<Review />} />

          {/* USER */}
          <Route path="/profile" element={<Profile />} />
          <Route path="/prfle" element={<Prfle />} />

          {/* INFO */}
          <Route path="/about" element={<About />} />
          <Route path="/faq" element={<Faq />} />

          {/* DEV / TEMP */}
          <Route path="/input" element={<Input />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
